A Pen created at CodePen.io. You can find this one at https://codepen.io/Izumenko/pen/KvrKqb.

 Original shot https://dribbble.com/shots/3369043-loader by Parveen rawat